import { Col, Input, Label, Row } from "reactstrap";
import type { TableFiltersProps } from "./types";

const TableFilters = ({ role, setRole, status, setStatus }: TableFiltersProps) => {
  return (
    <Row className="g-3 mb-3">
      <Col sm={4}>
        <Label className="form-label">Role</Label>
        <Input
          type="select"
          value={role}
          onChange={(e) => setRole(e.target.value)}
        >
          <option value="">All Roles</option>
          <option value="admin">Admin</option>
          <option value="superadmin">Super Admin</option>
          <option value="superuser">Super User</option>
          <option value="user">User</option>
        </Input>
      </Col>

      <Col sm={4}>
        <Label className="form-label">Status</Label>
        <Input
          type="select"
          value={status}
          onChange={(e) => setStatus(e.target.value)}
        >
          <option value="">All Status</option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
          <option value="pending">Pending</option>
        </Input>
      </Col>
    </Row>
  );
};

export default TableFilters;
