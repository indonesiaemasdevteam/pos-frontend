"use client";

import { useEffect, useState, useMemo, useCallback } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import {
  Card,
  CardBody,
  CardHeader,
  Col,
  Input,
  Row,
  Pagination,
  PaginationItem,
  PaginationLink,
} from "reactstrap";
import classnames from "classnames";
import { Crown, ShieldCheck, Star, User } from "lucide-react";
import { toast } from "react-toastify";

import {
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getSortedRowModel,
  useReactTable,
  type RowSelectionState,
  type SortingState,
} from "@tanstack/react-table";

import TableFilters from "./TableFilters";
import AddUserDrawer from "./AddUserDrawer";
import EditUserDialog from "./EditUserDialog";
import DeleteUserDialog from "./DeleteUserDialog";

import { DUMMY_COUNTRIES, DUMMY_USERS } from "./dummy";
import type { RoleValue, User as UserType, UserListTableProps } from "./types";

// ─── Helpers ──────────────────────────────────────────────────────────────────
const formatDate = (dateStr?: string): string => {
  if (!dateStr) return "-";
  return new Date(dateStr).toLocaleString("en-GB", {
    dateStyle: "medium",
    timeStyle: "short",
  });
};

const getInitials = (name: string) =>
  name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

const STATUS_BADGE: Record<string, string> = {
  active: "success",
  inactive: "secondary",
  pending: "warning",
};

const getRoleIcon = (role: RoleValue) => {
  switch (role) {
    case "superadmin": return <Crown size={15} className="text-warning me-1" />;
    case "superuser":  return <Star size={15} className="text-purple me-1" />;
    case "admin":      return <ShieldCheck size={15} className="text-primary me-1" />;
    default:           return <User size={15} className="text-muted me-1" />;
  }
};

// ─── Debounced Input ──────────────────────────────────────────────────────────
interface DebouncedInputProps {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  debounce?: number;
}
const DebouncedInput = ({
  value: init,
  onChange,
  placeholder,
  debounce = 400,
}: DebouncedInputProps) => {
  const [val, setVal] = useState(init);
  useEffect(() => { setVal(init); }, [init]);
  useEffect(() => {
    const t = setTimeout(() => onChange(val), debounce);
    return () => clearTimeout(t);
  }, [val]);
  return (
    <Input
      value={val}
      onChange={(e) => setVal(e.target.value)}
      placeholder={placeholder}
      style={{ width: 220 }}
    />
  );
};

// ─── Column helper ────────────────────────────────────────────────────────────
const columnHelper = createColumnHelper<UserType>();

// ─── Component ────────────────────────────────────────────────────────────────
const UserListTable = ({ session, countriesdata }: UserListTableProps) => {
  const { lang: locale } = useParams();
  const countries = countriesdata ?? DUMMY_COUNTRIES;
  const isSuperAdmin = session?.user?.roles?.some((r) => r.role === "superadmin");

  const [allData, setAllData]             = useState<UserType[]>(DUMMY_USERS);
  const [addOpen, setAddOpen]             = useState(false);
  const [editOpen, setEditOpen]           = useState(false);
  const [deleteOpen, setDeleteOpen]       = useState(false);
  const [selectedUser, setSelectedUser]   = useState<UserType | null>(null);
  const [rowSelection, setRowSelection]   = useState<RowSelectionState>({});
  const [globalFilter, setGlobalFilter]   = useState("");
  const [role, setRole]                   = useState("");
  const [status, setStatus]               = useState("");
  const [sorting, setSorting]             = useState<SortingState>([]);
  const [page, setPage]                   = useState(0);
  const [pageSize, setPageSize]           = useState(10);

  // ── Client-side filter / sort / paginate ──────────────────────────────────
  const filtered = useMemo(() => {
    let rows = [...allData];
    if (globalFilter) {
      const q = globalFilter.toLowerCase();
      rows = rows.filter(
        (u) =>
          u.name.toLowerCase().includes(q) ||
          u.username.toLowerCase().includes(q) ||
          u.email.toLowerCase().includes(q)
      );
    }
    if (role)   rows = rows.filter((u) => u.roles?.[0]?.role === role);
    if (status) rows = rows.filter((u) => u.status === status);
    if (sorting.length) {
      const { id, desc } = sorting[0];
      rows.sort((a, b) => {
        const av = (a as Record<string, unknown>)[id] ?? "";
        const bv = (b as Record<string, unknown>)[id] ?? "";
        if (av < bv) return desc ? 1 : -1;
        if (av > bv) return desc ? -1 : 1;
        return 0;
      });
    }
    return rows;
  }, [allData, globalFilter, role, status, sorting]);

  const paginated = useMemo(
    () => filtered.slice(page * pageSize, page * pageSize + pageSize),
    [filtered, page, pageSize]
  );

  useEffect(() => { setPage(0); }, [role, status, globalFilter, sorting]);

  const handleSave = useCallback(
    (updated: UserType) =>
      setAllData((prev) => prev.map((u) => (u.id === updated.id ? updated : u))),
    []
  );

  const handleDelete = useCallback((userId: string) => {
    setAllData((prev) =>
      prev.map((u) =>
        u.id === userId
          ? { ...u, deletedAt: new Date().toISOString(), status: "inactive" }
          : u
      )
    );
    toast.success("User deleted successfully");
  }, []);

  // ── Columns ───────────────────────────────────────────────────────────────
  const columns = useMemo(
    () => [
      {
        id: "select",
        header: ({ table }: any) => (
          <input
            type="checkbox"
            className="form-check-input"
            checked={table.getIsAllRowsSelected()}
            onChange={table.getToggleAllRowsSelectedHandler()}
          />
        ),
        cell: ({ row }: any) => (
          <input
            type="checkbox"
            className="form-check-input"
            checked={row.getIsSelected()}
            disabled={!row.getCanSelect()}
            onChange={row.getToggleSelectedHandler()}
          />
        ),
      },
      columnHelper.accessor("name", {
        header: "User",
        cell: ({ row }) => {
          const { image, name, username } = row.original;
          return (
            <div className="d-flex align-items-center gap-2">
              {image ? (
                <img
                  src={image}
                  alt={name}
                  className="rounded-circle avatar-xs"
                />
              ) : (
                <div
                  className="avatar-xs rounded-circle bg-primary d-flex align-items-center justify-content-center text-white"
                  style={{ fontSize: 12, fontWeight: 600 }}
                >
                  {getInitials(name)}
                </div>
              )}
              <div>
                <p className="mb-0 fw-semibold">{name}</p>
                <small className="text-muted">@{username}</small>
              </div>
            </div>
          );
        },
      }),
      columnHelper.accessor("email", {
        header: "Email",
        cell: ({ row }) => (
          <small className="text-muted">{row.original.email}</small>
        ),
      }),
      columnHelper.accessor("roles", {
        header: "Role",
        cell: ({ row }) => {
          const roleVal = row.original.roles?.[0]?.role ?? "user";
          return (
            <div className="d-flex align-items-center text-capitalize">
              {getRoleIcon(roleVal)}
              <span>{roleVal}</span>
            </div>
          );
        },
      }),
      columnHelper.accessor("status", {
        header: "Status",
        cell: ({ row }) => (
          <span
            className={`badge bg-${STATUS_BADGE[row.original.status] ?? "secondary"}-subtle text-${STATUS_BADGE[row.original.status] ?? "secondary"} text-capitalize`}
          >
            {row.original.status}
          </span>
        ),
      }),
      columnHelper.accessor("country", {
        header: "Country",
        cell: ({ row }) => {
          const { country, countryCode } = row.original;
          return (
            <div className="d-flex align-items-center gap-1">
              {countryCode && (
                <img
                  src={`https://flagcdn.com/w40/${countryCode}.png`}
                  alt={country}
                  width={20}
                  height={14}
                  style={{ objectFit: "cover", borderRadius: 2 }}
                />
              )}
              <small>{country || "-"}</small>
            </div>
          );
        },
      }),
      columnHelper.accessor("phoneNumber", {
        header: "Phone",
        cell: ({ row }) => (
          <small className="text-muted">
            {(row.original.phoneNumber || "-").replace(/-/g, "")}
          </small>
        ),
      }),
      columnHelper.accessor("createdAt", {
        header: "Joined",
        cell: ({ row }) => (
          <small>{formatDate(row.original.createdAt)}</small>
        ),
      }),
      columnHelper.accessor("lastLogin", {
        header: "Last Login",
        cell: ({ row }) => (
          <small>{formatDate(row.original.lastLogin)}</small>
        ),
      }),
      columnHelper.display({
        id: "action",
        header: "Action",
        enableSorting: false,
        cell: ({ row }) => {
          const isDeleted = !!row.original.deletedAt;
          return (
            <div className="d-flex gap-1">
              {/* Edit */}
              <button
                className="btn btn-sm btn-soft-primary"
                onClick={() => {
                  setSelectedUser(row.original);
                  setEditOpen(true);
                }}
                title="Edit"
              >
                <i className="ri-pencil-line" />
              </button>

              {/* Delete */}
              <button
                className="btn btn-sm btn-soft-danger"
                disabled={isDeleted || !isSuperAdmin}
                onClick={() => {
                  if (!isDeleted && isSuperAdmin) {
                    setSelectedUser(row.original);
                    setDeleteOpen(true);
                  }
                }}
                title="Delete"
              >
                <i className="ri-delete-bin-line" />
              </button>

              {/* View */}
              <Link
                href={`/${locale}/apps/user/view`}
                className="btn btn-sm btn-soft-info"
                title="View"
              >
                <i className="ri-eye-line" />
              </Link>
            </div>
          );
        },
      }),
    ],
    [locale, isSuperAdmin]
  );

  const table = useReactTable({
    data: paginated,
    columns,
    state: { rowSelection, globalFilter, sorting },
    onRowSelectionChange: setRowSelection,
    onGlobalFilterChange: setGlobalFilter,
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getSortedRowModel: getSortedRowModel(),
    manualPagination: true,
    manualSorting: true,
    pageCount: Math.ceil(filtered.length / pageSize),
  });

  // ── Pagination ────────────────────────────────────────────────────────────
  const totalPages = Math.ceil(filtered.length / pageSize);

  return (
    <>
      <Card>
        <CardHeader>
          <h5 className="card-title mb-0">User Management</h5>
        </CardHeader>
        <CardBody>
          {/* Filters */}
          <TableFilters
            role={role}
            setRole={setRole}
            status={status}
            setStatus={setStatus}
          />

          {/* Toolbar */}
          <Row className="align-items-center mb-3 g-2">
            <Col sm="auto">
              <Input
                type="select"
                value={pageSize}
                onChange={(e) => {
                  setPageSize(Number(e.target.value));
                  setPage(0);
                }}
                style={{ width: 80 }}
              >
                {[10, 25, 50].map((v) => (
                  <option key={v} value={v}>{v}</option>
                ))}
              </Input>
            </Col>
            <Col sm="auto" className="ms-auto">
              <div className="d-flex gap-2">
                <DebouncedInput
                  value={globalFilter}
                  onChange={setGlobalFilter}
                  placeholder="Search user..."
                />
                <button className="btn btn-soft-secondary">
                  <i className="ri-download-2-line me-1" />
                  Export
                </button>
                <button
                  className="btn btn-primary"
                  onClick={() => setAddOpen(true)}
                >
                  <i className="ri-add-line me-1" />
                  Add User
                </button>
              </div>
            </Col>
          </Row>

          {/* Table */}
          <div className="table-responsive">
            <table className="table table-hover table-nowrap align-middle mb-0">
              <thead className="table-light">
                {table.getHeaderGroups().map((hg) => (
                  <tr key={hg.id}>
                    {hg.headers.map((header) => (
                      <th
                        key={header.id}
                        className={classnames("text-uppercase fs-12 fw-semibold", {
                          "cursor-pointer user-select-none":
                            header.column.getCanSort(),
                        })}
                        onClick={header.column.getToggleSortingHandler()}
                      >
                        {header.isPlaceholder
                          ? null
                          : flexRender(
                              header.column.columnDef.header,
                              header.getContext()
                            )}
                        {header.column.getIsSorted() === "asc" && (
                          <i className="ri-arrow-up-s-line ms-1" />
                        )}
                        {header.column.getIsSorted() === "desc" && (
                          <i className="ri-arrow-down-s-line ms-1" />
                        )}
                      </th>
                    ))}
                  </tr>
                ))}
              </thead>
              <tbody>
                {paginated.length === 0 ? (
                  <tr>
                    <td
                      colSpan={table.getVisibleFlatColumns().length}
                      className="text-center text-muted py-4"
                    >
                      No users found
                    </td>
                  </tr>
                ) : (
                  table.getRowModel().rows.map((row) => (
                    <tr
                      key={row.id}
                      className={row.getIsSelected() ? "table-active" : ""}
                    >
                      {row.getVisibleCells().map((cell) => (
                        <td key={cell.id}>
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </td>
                      ))}
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="d-flex justify-content-between align-items-center mt-3">
            <small className="text-muted">
              Showing {page * pageSize + 1}–
              {Math.min((page + 1) * pageSize, filtered.length)} of{" "}
              {filtered.length} users
            </small>
            <Pagination className="mb-0">
              <PaginationItem disabled={page === 0}>
                <PaginationLink first onClick={() => setPage(0)} />
              </PaginationItem>
              <PaginationItem disabled={page === 0}>
                <PaginationLink previous onClick={() => setPage((p) => p - 1)} />
              </PaginationItem>
              {Array.from({ length: totalPages }, (_, i) => (
                <PaginationItem key={i} active={i === page}>
                  <PaginationLink onClick={() => setPage(i)}>
                    {i + 1}
                  </PaginationLink>
                </PaginationItem>
              ))}
              <PaginationItem disabled={page >= totalPages - 1}>
                <PaginationLink
                  next
                  onClick={() => setPage((p) => p + 1)}
                />
              </PaginationItem>
              <PaginationItem disabled={page >= totalPages - 1}>
                <PaginationLink
                  last
                  onClick={() => setPage(totalPages - 1)}
                />
              </PaginationItem>
            </Pagination>
          </div>
        </CardBody>
      </Card>

      {/* Drawers / Dialogs */}
      <AddUserDrawer
        open={addOpen}
        handleClose={() => setAddOpen(false)}
        userData={allData}
        setData={setAllData}
        countries={countries}
      />

      {selectedUser && (
        <EditUserDialog
          open={editOpen}
          setOpen={setEditOpen}
          data={selectedUser}
          session={session}
          countries={countries}
          onSave={handleSave}
        />
      )}

      {selectedUser && (
        <DeleteUserDialog
          open={deleteOpen}
          setOpen={setDeleteOpen}
          user={selectedUser}
          onDelete={handleDelete}
          onClose={() => setSelectedUser(null)}
        />
      )}
    </>
  );
};

export default UserListTable;
