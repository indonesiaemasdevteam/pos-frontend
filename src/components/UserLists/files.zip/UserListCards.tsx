"use client";

import { useMemo } from "react";
import { Card, CardBody, Col, Row } from "reactstrap";
import { DUMMY_USERS } from "./dummy";

interface StatCard {
  title: string;
  count: number;
  icon: string;
  color: string;
  subtitle: string;
}

const UserListCards = () => {
  const stats = useMemo(() => {
    const todayWIB = new Date().toLocaleDateString("en-CA", {
      timeZone: "Asia/Jakarta",
    });
    return {
      total: DUMMY_USERS.length,
      active: DUMMY_USERS.filter((u) => u.status === "active").length,
      inactive: DUMMY_USERS.filter((u) => u.status === "inactive").length,
      loggedInToday: DUMMY_USERS.filter(
        (u) => u.lastLogin?.startsWith(todayWIB)
      ).length,
    };
  }, []);

  const cards: StatCard[] = [
    {
      title: "Total Users",
      count: stats.total,
      icon: "ri-group-line",
      color: "primary",
      subtitle: "All registered users",
    },
    {
      title: "Active",
      count: stats.active,
      icon: "ri-user-follow-line",
      color: "success",
      subtitle: "Active accounts",
    },
    {
      title: "Inactive",
      count: stats.inactive,
      icon: "ri-user-unfollow-line",
      color: "secondary",
      subtitle: "Inactive accounts",
    },
    {
      title: "Logged In Today",
      count: stats.loggedInToday,
      icon: "ri-time-line",
      color: "info",
      subtitle: "Last login today",
    },
  ];

  return (
    <Row>
      {cards.map((card, i) => (
        <Col key={i} xxl={3} sm={6}>
          <Card className="card-animate">
            <CardBody>
              <div className="d-flex justify-content-between">
                <div>
                  <p className="fw-medium text-muted mb-0">{card.title}</p>
                  <h2 className="mt-4 ff-secondary fw-semibold">
                    {card.count.toLocaleString()}
                  </h2>
                  <p className="mb-0 text-muted">
                    <span className="badge bg-light text-muted me-1 align-middle">
                      {card.subtitle}
                    </span>
                  </p>
                </div>
                <div>
                  <div className={`avatar-sm flex-shrink-0`}>
                    <span
                      className={`avatar-title bg-${card.color}-subtle rounded-circle fs-2`}
                    >
                      <i className={`${card.icon} text-${card.color}`} />
                    </span>
                  </div>
                </div>
              </div>
            </CardBody>
          </Card>
        </Col>
      ))}
    </Row>
  );
};

export default UserListCards;
