import React from "react";
import { Row, Col } from "reactstrap";

import UserListTable from "./UserListTable";
import UserListCards from "./UserListCards";
import type { UserListProps } from "./types";

const UserList = ({ session, countriesdata }: UserListProps) => {
  return (
    <React.Fragment>
      <Row>
        <Col xs={12}>
          <UserListCards />
        </Col>
      </Row>
      <Row>
        <Col xs={12}>
          <UserListTable session={session} countriesdata={countriesdata} />
        </Col>
      </Row>
    </React.Fragment>
  );
};

export default UserList;
